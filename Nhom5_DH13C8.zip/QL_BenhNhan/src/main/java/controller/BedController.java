package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BedDAO;
import DAO.RoomDAO; // THÊM IMPORT NÀY
import model.Bed;

@WebServlet("/BedController")
public class BedController extends HttpServlet {
	private BedDAO bedDAO;
	private RoomDAO roomDAO; // THÊM BIẾN NÀY

	@Override // THÊM OVERRIDE
	public void init() {
		System.out.println("🎯 BedController đang khởi tạo...");
		bedDAO = new BedDAO();
		roomDAO = new RoomDAO(); // KHỞI TẠO ROOMDAO
	}

	@Override // THÊM OVERRIDE
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");

		if ("updateStatus".equals(action)) {
			updateBedStatus(request, response);
		} else {
			// THÊM TRƯỜNG HỢP MẶC ĐỊNH
			doGet(request, response);
		}
	}

	@Override // THÊM OVERRIDE
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("🎯 BedController doGet được gọi");

		try {
			List<Bed> beds = bedDAO.getAllBedsWithRoomInfo();
			request.setAttribute("beds", beds);
			request.setAttribute("rooms", roomDAO.getAllRooms()); // THÊM DANH SÁCH PHÒNG
			request.setAttribute("availableBeds", bedDAO.getAvailableBeds());

			request.getRequestDispatcher("/staff/staff_statistic/staff_statistic.jsp").forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500, "Lỗi server: " + e.getMessage());
		}
	}

	private void updateBedStatus(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int bedId = Integer.parseInt(request.getParameter("bedId"));
			String status = request.getParameter("status");

			if (bedDAO.updateBedStatus(bedId, status)) {
				request.setAttribute("message", "Cập nhật trạng thái thành công!");
			} else {
				request.setAttribute("error", "Cập nhật trạng thái thất bại!");
			}
		} catch (NumberFormatException e) {
			request.setAttribute("error", "ID giường không hợp lệ!");
		} catch (Exception e) {
			request.setAttribute("error", "Lỗi: " + e.getMessage());
		}

		doGet(request, response);
	}
}