package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.DoctorDAO;
import DAO.ScheduleDAO;
import model.Doctor;
import model.Schedule;

@WebServlet("/ProcessStaffDoctor")
public class ProcessStaffDoctor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DoctorDAO doctorDAO;
	private ScheduleDAO scheduleDAO;

	public void init() {
		doctorDAO = new DoctorDAO();
		scheduleDAO = new ScheduleDAO();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");

		if (action == null)
			action = "list";

		try {
			switch (action) {
			case "list":
				List<Doctor> list = doctorDAO.getAllDoctors();

				request.setAttribute("doctors", list);
				request.getRequestDispatcher("/staff/staff_doctor/doctor_list.jsp").forward(request, response);
				break;

			case "viewSchedule":
				String idStr = request.getParameter("id");
				if (idStr != null) {
					int docId = Integer.parseInt(idStr);

					Doctor doc = doctorDAO.getDoctorById(docId);
					List<Schedule> schedules = scheduleDAO.getAvailableSchedules(docId);

					request.setAttribute("doctor", doc);
					request.setAttribute("schedules", schedules);

					request.getRequestDispatcher("/staff/staff_doctor/view_schedule.jsp").forward(request, response);
				} else {
					// Nếu không có ID, quay về danh sách
					response.sendRedirect("ProcessStaffDoctor?action=list");
				}
				break;

			default:
				response.sendRedirect("ProcessStaffDoctor?action=list");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setContentType("text/html;charset=UTF-8");
			response.getWriter().println("<h3>Lỗi hệ thống: " + e.getMessage() + "</h3>");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}