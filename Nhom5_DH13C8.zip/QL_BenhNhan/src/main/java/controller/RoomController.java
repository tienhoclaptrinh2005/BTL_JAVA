package controller;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BedDAO;
import DAO.RoomDAO;
import model.Bed;
import model.Room;

@WebServlet("/RoomController")
public class RoomController extends HttpServlet {
	private RoomDAO roomDAO;
	private BedDAO bedDAO;

	@Override
	public void init() {
		System.out.println("🎯 RoomController đang khởi tạo...");
		roomDAO = new RoomDAO();
		bedDAO = new BedDAO();
	}

	@Override // THÊM OVERRIDE
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");

		if ("addRoom".equals(action)) {
			addRoom(request, response);
		} else if ("addBed".equals(action)) {
			addBed(request, response);
		} else {
			// THÊM TRƯỜNG HỢP MẶC ĐỊNH
			doGet(request, response);
		}
	}

	@Override // THÊM OVERRIDE
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("🎯 RoomController doGet được gọi");

		try {
			// Lấy danh sách phòng và giường
			request.setAttribute("rooms", roomDAO.getAllRooms());
			request.setAttribute("beds", bedDAO.getAllBedsWithRoomInfo());
			request.setAttribute("totalRooms", roomDAO.getTotalRooms());
			request.setAttribute("totalBeds", bedDAO.getTotalBeds());
			request.setAttribute("availableBeds", bedDAO.getAvailableBeds());

			RequestDispatcher dispatcher = request.getRequestDispatcher("/admin/admin_statistic/admin_statistic.jsp");
			dispatcher.forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500, "Lỗi server: " + e.getMessage());
		}
	}

	private void addRoom(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String roomNumber = request.getParameter("roomNumber");
		String type = request.getParameter("type");
		String priceStr = request.getParameter("pricePerDay");

		try {
			BigDecimal pricePerDay = new BigDecimal(priceStr);
			Room room = new Room(0, roomNumber, type, pricePerDay);

			if (roomDAO.addRoom(room)) {
				request.setAttribute("message", "Thêm phòng thành công!");
			} else {
				request.setAttribute("error", "Thêm phòng thất bại!");
			}
		} catch (Exception e) {
			request.setAttribute("error", "Dữ liệu không hợp lệ: " + e.getMessage());
		}

		doGet(request, response);
	}

	private void addBed(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int roomId = Integer.parseInt(request.getParameter("roomId"));
			String bedNumber = request.getParameter("bedNumber");

			Bed bed = new Bed(0, roomId, bedNumber, "Trong");

			if (bedDAO.addBed(bed)) {
				request.setAttribute("message", "Thêm giường thành công!");
			} else {
				request.setAttribute("error", "Thêm giường thất bại!");
			}
		} catch (NumberFormatException e) {
			request.setAttribute("error", "ID phòng không hợp lệ!");
		} catch (Exception e) {
			request.setAttribute("error", "Lỗi: " + e.getMessage());
		}

		doGet(request, response);
	}
}