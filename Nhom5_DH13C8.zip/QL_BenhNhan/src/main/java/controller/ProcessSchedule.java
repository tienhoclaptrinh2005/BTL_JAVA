package controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.ScheduleDAO;
import model.Schedule;

@WebServlet("/ProcessSchedule")
public class ProcessSchedule extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ProcessSchedule() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		int doctorId = 0;

		try {

			String idStr = request.getParameter("doctorId");
			String dateStr = request.getParameter("workDate");
			String shiftStr = request.getParameter("shift");

			if (idStr == null || dateStr == null || shiftStr == null) {
				throw new Exception("Dữ liệu gửi lên bị thiếu! ID=" + idStr + ", Date=" + dateStr);
			}

			doctorId = Integer.parseInt(idStr);
			Date workDate = Date.valueOf(dateStr);
			int shift = Integer.parseInt(shiftStr);

			Schedule s = new Schedule();
			s.setDoctorId(doctorId);
			s.setWorkDate(workDate);
			s.setShift(shift);
			s.setBooked(false);

			ScheduleDAO dao = new ScheduleDAO();
			dao.addSchedule(s);

			response.sendRedirect("ProcessDoctor?action=viewSchedule&id=" + doctorId);

		} catch (Exception e) {
			e.printStackTrace();
			response.setContentType("text/html;charset=UTF-8");
			response.getWriter().println("<h3>LỖI XẾP LỊCH: " + e.getMessage() + "</h3>");
			response.getWriter().println("<p>ID Bác sĩ nhận được: " + doctorId + "</p>");
			response.getWriter().println("<a href='javascript:history.back()'>Quay lại</a>");
		}
	}
}