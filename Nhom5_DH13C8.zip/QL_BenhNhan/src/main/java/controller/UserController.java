package controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.UserDAO;
import model.User;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		if (action == null) {
			action = "list";
		}
		switch (action) {
		case "new":
			showNewForm(request, response);
			break;
		case "delete":
			deleteUser(request, response);
			break;
		case "edit":
			showEditForm(request, response);
			break;
		case "search":
			searchUser(request, response);
			break;
		default:
			listUsers(request, response);
			break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		if ("insert".equals(action)) {
			insertUser(request, response);
		} else if ("update".equals(action)) {
			updateUser(request, response);
		} else {
			doGet(request, response);
		}
	}

	private void listUsers(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserDAO userDAO = new UserDAO();
		List<User> list = userDAO.getAllUsers();
		request.setAttribute("listUsers", list);

		request.getRequestDispatcher("/admin/admin_users/admin_users.jsp").forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/admin/admin_users/add_user.jsp").forward(request, response);
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		UserDAO userDAO = new UserDAO();
		userDAO.deleteUser(id);
		response.sendRedirect(request.getContextPath() + "/UserController");
	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("UTF-8");
		UserDAO userDAO = new UserDAO();
		User newUser = new User();
		newUser.setUsername(request.getParameter("username"));
		newUser.setPassword(request.getParameter("password"));
		newUser.setFullName(request.getParameter("fullname"));
		newUser.setEmail(request.getParameter("email"));
		newUser.setPhone(request.getParameter("phone"));
		newUser.setRole(request.getParameter("role"));
		newUser.setActive(true);
		newUser.setCreatedAt(new Timestamp(System.currentTimeMillis()));

		userDAO.insertUser(newUser);

		response.sendRedirect(request.getContextPath() + "/UserController");
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserDAO userDAO = new UserDAO();
		int id = Integer.parseInt(request.getParameter("id"));
		User existingUser = userDAO.getUserById(id);

		request.setAttribute("user", existingUser);
		request.getRequestDispatcher("/admin/admin_users/edit_user.jsp").forward(request, response);
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		UserDAO userDAO = new UserDAO();
		int id = Integer.parseInt(request.getParameter("id"));
		String password = request.getParameter("password");
		String fullname = request.getParameter("fullname");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String role = request.getParameter("role");
		boolean isActive = Boolean.parseBoolean(request.getParameter("isActive"));

		User user = new User();
		user.setId(id);
		user.setPassword(password);
		user.setFullName(fullname);
		user.setEmail(email);
		user.setPhone(phone);
		user.setRole(role);
		user.setActive(isActive);

		userDAO.updateUser(user);

		response.sendRedirect(request.getContextPath() + "/UserController");
	}

	private void searchUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String keyword = request.getParameter("keyword");
		UserDAO userDAO = new UserDAO();

		// Nếu từ khóa rỗng thì hiện tất cả
		List<User> list;
		if (keyword == null || keyword.trim().isEmpty()) {
			list = userDAO.getAllUsers();
		} else {
			list = userDAO.searchUsers(keyword.trim());
		}

		request.setAttribute("listUsers", list);
		request.setAttribute("keyword", keyword);
		request.getRequestDispatcher("/admin/admin_users/admin_users.jsp").forward(request, response);
	}
}
