package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.UserDAO;
import model.User;

/**
 * Servlet implementation class ProcessLogin
 */
@WebServlet("/login")
public class ProcessLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProcessLogin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("login.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String u = request.getParameter("username");
		String p = request.getParameter("password");

		UserDAO dao = new UserDAO();
		User user = dao.checkLogin(u, p);

		if (user == null) {
			// Đăng nhập thất bại
			request.setAttribute("errorMessage", "Sai thông tin hoặc tài khoản bị khóa!");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		} else {
			// Đăng nhập thành công -> Lưu vào Session
			HttpSession session = request.getSession();
			session.setAttribute("account", user);
			// Phân quyền
			if ("QuanTriVien".equals(user.getRole())) {
				response.sendRedirect("admin/dashboard.jsp");
			} else {
				response.sendRedirect("staff/home.jsp");
			}
		}
	}

}
