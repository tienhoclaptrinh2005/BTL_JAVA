package controller;

import DAO.PatientDAO;
import model.Patient;
import java.io.IOException;
import java.sql.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/patient")
public class PatientController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        String keyword = request.getParameter("keyword");

        if ("search".equals(action) && keyword != null) {
            PatientDAO dao = new PatientDAO();
            List<Patient> list = dao.searchPatient(keyword);
            request.setAttribute("listP", list);
        }
        
        request.getRequestDispatcher("staff/staff_patient/add_patient.jsp").forward(request, response);
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            try {
                Patient p = new Patient();
                p.setFullName(request.getParameter("fullname"));
                p.setDob(Date.valueOf(request.getParameter("dob")));
                p.setGender(request.getParameter("gender"));
                p.setPhone(request.getParameter("phone"));
                p.setAddress(request.getParameter("address"));
                p.setInsuranceCard(request.getParameter("insurance"));

                new PatientDAO().addPatient(p);
                
//                response.sendRedirect("staff/staff_patient/add_patient.jsp?msg=added");
                response.sendRedirect(request.getContextPath() + "/patient?msg=added");
            } catch (Exception e) {
                e.printStackTrace();
//                response.sendRedirect("staff/staff_patient/add_patient.jsp?msg=error");
                response.sendRedirect(request.getContextPath() + "/patient?msg=error");
            }
        }
    }
}