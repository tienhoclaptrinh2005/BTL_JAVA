package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.MedicineDAO;
import DAO.PrescriptionDAO;
import model.CartItem;
import model.Medicine;

/**
 * Servlet implementation class ProcessMedicine
 */
@WebServlet("/ProcessMedicine")
public class ProcessMedicine extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	private MedicineDAO medicineDAO;

	public ProcessMedicine() {
		super();
		medicineDAO = new MedicineDAO();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		String action = request.getParameter("action");
		if (action == null) {
			action = "list"; // mac dinh la danh sach kho
		}

		switch (action) {
		case "list":
			showListMedicine(request, response);
			break;
		case "search":
			searchMedicine(request, response);
			break;
		case "addToCart":
			addToCart(request, response);
			break;
		case "removeFromCart":
			removeFromCart(request, response);
			break;
		default:
			showListMedicine(request, response);
			break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		String action = request.getParameter("action");
		if ("import".equals(action)) {
			// chuc nang nhap kho(tang so luong
			int id = Integer.parseInt(request.getParameter("id"));
			int amountToAdd = Integer.parseInt(request.getParameter("amount"));

			medicineDAO.importStock(id, amountToAdd);

			// xu ly xong thi load lai tran danh sach
			response.sendRedirect(request.getContextPath() + "/ProcessMedicine?action=list");

		} else if ("updatePrice".equals(action)) {
			// chuc nang sua gia thuoc
			int id = Integer.parseInt(request.getParameter("id"));
			double newPrice = Double.parseDouble(request.getParameter("newPrice"));

			medicineDAO.updatePrice(id, newPrice);
			response.sendRedirect(request.getContextPath() + "/ProcessMedicine?action=list");

		} else if ("checkout".equals(action)) {
			// 1. Lấy thông tin từ form
			String patientName = request.getParameter("patientName");
			String note = request.getParameter("note");
			String fullNote = "KH: " + patientName + " - " + note; // Gom lại lưu vào cột note

			// 2. Lấy giỏ hàng
			HttpSession session = request.getSession();
			List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

			if (cart != null && !cart.isEmpty()) {
				// 3. Gọi DAO để lưu
				PrescriptionDAO presDao = new PrescriptionDAO();
				boolean success = presDao.savePrescription(fullNote, cart);

				if (success) {
					// Lưu thành công -> Xóa giỏ hàng
					session.removeAttribute("cart");
					// Chuyển hướng báo thành công (Có thể tạo trang success.jsp nếu muốn)
					response.sendRedirect(request.getContextPath() + "/ProcessMedicine?action=search&status=success");
				} else {
					response.sendRedirect(request.getContextPath() + "/ProcessMedicine?action=search&status=fail");
				}
			} else {
				response.sendRedirect(request.getContextPath() + "/ProcessMedicine?action=search");
			}
		}
	}

	// hien thi danh sach thuoc cho admin
	private void showListMedicine(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Medicine> list = medicineDAO.getAllMedicines();
		request.setAttribute("medicineList", list);
		// chuyen sang file giao dien admin
		request.getRequestDispatcher("/admin/admin_medicine/admin_medicine.jsp").forward(request, response);

	}

	// tim kiem thuoc cho nhan vien
	private void searchMedicine(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String keyword = request.getParameter("keyword");
		List<Medicine> list = medicineDAO.searchMedicine(keyword);

		request.setAttribute("medicineList", list);
		// chuyen sang file giao dien nhan vien
		request.getRequestDispatcher("/staff/staff_medicine.jsp").forward(request, response);
	}

	// ham xu ly gio hang(session)
	private void addToCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// lay thong tin don thuo duoc chon
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		double price = Double.parseDouble(request.getParameter("price"));
		int quantily = 1;

		// lay gio hang tu session ra(list)
		HttpSession session = request.getSession();
		List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

		// neu chua co gio thi tao moi
		if (cart == null) {
			cart = new ArrayList();

		}

		// ktra xem thuoc da co trong gio chua
		boolean found = false;
		for (CartItem item : cart) {
			if (item.getMedicineId() == id) {
				item.setQuantity(item.getQuantity() + 1); // co thi tang so luong
				found = true;
				break;
			}
		}

		// neu chua co thi them moi vao
		if (!found) {
			cart.add(new CartItem(id, name, price, quantily));
		}

		// luu nguoc lai vao session
		session.setAttribute("cart", cart);

		// quay nguoc lai trang tim kieem(giu nguyeen khoa tim kieem cux neu co
		String keyword = request.getParameter("keyword");
		response.sendRedirect(request.getContextPath() + "/ProcessMedicine?action=search&keyword=" + keyword);

	}

	// ham xoa thuoc khoi gio
	private void removeFromCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		HttpSession session = request.getSession();
		List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

		if (cart != null) {
			for (int i = 0; i < cart.size(); i++) {
				if (cart.get(i).getMedicineId() == id) {
					cart.remove(i);
					break;
				}
			}
		}
		session.setAttribute("cart", cart);

		String keyword = request.getParameter("keyword");
		// ktra keyword = null de tranh loi chuoi
		if (keyword == null)
			keyword = "";
		response.sendRedirect(request.getContextPath() + "/ProcessMedicine?action=search&keyword=" + keyword);
	}

}