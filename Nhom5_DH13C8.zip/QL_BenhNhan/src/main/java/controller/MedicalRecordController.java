package controller;

import DAO.DBConfig;
import DAO.MedicalRecordDAO;
import DAO.ScheduleDAO;
import model.MedicalRecord;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/medical-record")
public class MedicalRecordController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        
        if ("create".equals(action)) {
            Connection conn = null;
            try {
                // 1. Lấy dữ liệu
                int patientId = Integer.parseInt(request.getParameter("patientId"));
                int doctorId = Integer.parseInt(request.getParameter("doctorId"));
                int scheduleId = Integer.parseInt(request.getParameter("scheduleId"));
                String symptoms = request.getParameter("symptoms");
                
                // 2. Transaction (Tạo bệnh án + Cập nhật lịch)
                conn = new DBConfig().getConnection();
                conn.setAutoCommit(false); 

                MedicalRecord record = new MedicalRecord(patientId, doctorId, scheduleId, symptoms, "Chờ khám");
                new MedicalRecordDAO().insertRecord(conn, record);
                new ScheduleDAO().updateBookedCount(conn, scheduleId);

                conn.commit(); 
                
                // --- SỬA LẠI ĐƯỜNG DẪN ---
                // Thành công: Quay về trang danh sách bệnh nhân (staff_patient)
                response.sendRedirect(request.getContextPath() + "/staff/staff_patient/add_patient.jsp?msg=success");

            } catch (Exception e) {
                e.printStackTrace();
                if (conn != null) try { conn.rollback(); } catch (SQLException ex) {}
                
                // Lỗi: Quay lại trang tạo bệnh án
                response.sendRedirect(request.getContextPath() + "/staff/staff_medical_record/create_record.jsp?msg=error");
            } finally {
                if (conn != null) try { conn.close(); } catch (SQLException e) {}
            }
        }
    }
}