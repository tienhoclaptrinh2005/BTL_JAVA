package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.DoctorDAO;
import model.Doctor;
import model.Schedule;
import model.Specialty;

@WebServlet("/ProcessDoctor")
public class ProcessDoctor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DoctorDAO dao;

	public void init() {
		dao = new DoctorDAO();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		if (action == null)
			action = "list";

		try {
			switch (action) {
			case "list":
				List<Doctor> list = dao.getAllDoctors();
				request.setAttribute("doctors", list);
				request.getRequestDispatcher("/admin/admin_doctor/doctor_manager.jsp").forward(request, response);
				break;

			case "delete":
				int id = Integer.parseInt(request.getParameter("id"));
				dao.deleteDoctor(id);
				response.sendRedirect("ProcessDoctor?action=list");
				break;

			case "search":
				String keyword = request.getParameter("keyword");
				List<Doctor> searchList = dao.searchDoctor(keyword);
				request.setAttribute("doctors", searchList);
				request.getRequestDispatcher("/admin/admin_doctor/doctor_manager.jsp").forward(request, response);
				break;

			case "add":
				List<Specialty> specs = dao.getAllSpecialties();
				request.setAttribute("specialties", specs);
				request.getRequestDispatcher("/admin/admin_doctor/add_doctor.jsp").forward(request, response);
				break;

			case "edit":
				int editId = Integer.parseInt(request.getParameter("id"));
				Doctor d = dao.getDoctorById(editId);
				List<Specialty> specsForEdit = dao.getAllSpecialties();

				request.setAttribute("doctor", d);
				request.setAttribute("specialties", specsForEdit);
				request.getRequestDispatcher("/admin/admin_doctor/edit_doctor.jsp").forward(request, response);
				break;

			case "viewSchedule":
				int docId = Integer.parseInt(request.getParameter("id"));

				Doctor doc = dao.getDoctorById(docId);

				List<Schedule> scheduleList = dao.getSchedulesByDoctor(docId);

				request.setAttribute("doctor", doc);
				request.setAttribute("schedules", scheduleList);

				request.getRequestDispatcher("/admin/admin_doctor/schedule_doctor.jsp").forward(request, response);
				break;

			default:
				response.sendRedirect("ProcessDoctor?action=list");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setContentType("text/html;charset=UTF-8");
			response.getWriter().println("<h1>Đã xảy ra lỗi!</h1>");
			response.getWriter().println("<h3>Chi tiết lỗi: " + e.getMessage() + "</h3>");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");

		try {
			if ("add".equals(action)) {
				int userId = Integer.parseInt(request.getParameter("userId"));
				int specialtyId = Integer.parseInt(request.getParameter("specialtyId"));
				String degree = request.getParameter("degree");
				String bio = request.getParameter("bio");

				Doctor d = new Doctor();
				d.setUserId(userId);
				d.setSpecialtyId(specialtyId);
				d.setDegree(degree);
				d.setBio(bio);

				dao.addDoctor(d);
				response.sendRedirect("ProcessDoctor?action=list");

			} else if ("update".equals(action)) {
				int id = Integer.parseInt(request.getParameter("id"));
				int specialtyId = Integer.parseInt(request.getParameter("specialtyId"));
				String degree = request.getParameter("degree");
				String bio = request.getParameter("bio");

				Doctor d = new Doctor();
				d.setId(id);
				d.setSpecialtyId(specialtyId);
				d.setDegree(degree);
				d.setBio(bio);

				dao.updateDoctor(d);
				response.sendRedirect("ProcessDoctor?action=list");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().println("Lỗi khi lưu dữ liệu: " + e.getMessage());
		}
	}
}