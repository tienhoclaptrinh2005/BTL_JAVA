package model;
import java.sql.Date;

public class MedicalRecord {
    private int id;
    private int patientId;
    private int doctorId;
    private Integer bedId;      // Integer để lưu null
    private String diagnosis;
    private String symptoms;
    private Date admissionDate;
    private Date dischargeDate;
    private String status;
    private int scheduleId;     // Thêm để xử lý logic lịch

    public MedicalRecord() {}

    // Constructor tạo mới
    public MedicalRecord(int patientId, int doctorId, int scheduleId, String symptoms, String diagnosis) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.scheduleId = scheduleId;
        this.symptoms = symptoms;
        this.diagnosis = diagnosis;
        this.admissionDate = new Date(System.currentTimeMillis());
        this.status = "Chờ khám";
        this.bedId = null; 
        this.dischargeDate = null;
    }

    // Getters & Setters
    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }
    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }
    public Integer getBedId() { return bedId; }
    public void setBedId(Integer bedId) { this.bedId = bedId; }
    public String getDiagnosis() { return diagnosis; }
    public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }
    public String getSymptoms() { return symptoms; }
    public void setSymptoms(String symptoms) { this.symptoms = symptoms; }
    public Date getAdmissionDate() { return admissionDate; }
    public void setAdmissionDate(Date admissionDate) { this.admissionDate = admissionDate; }
    public Date getDischargeDate() { return dischargeDate; }
    public void setDischargeDate(Date dischargeDate) { this.dischargeDate = dischargeDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getScheduleId() { return scheduleId; }
    public void setScheduleId(int scheduleId) { this.scheduleId = scheduleId; }
}