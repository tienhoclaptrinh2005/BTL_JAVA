package model;

public class Medicine {
	private int id;
	private String name;
	private String unit;
	private double price;
	private int stockQuantity;
	private String usageInstruction;

	// 1. Constructor rỗng
	public Medicine() {
	}

	// 2. Constructor đầy đủ
	public Medicine(int id, String name, String unit, double price, int stockQuantity, String usageInstruction) {
		this.id = id;
		this.name = name;
		this.unit = unit;
		this.price = price;
		this.stockQuantity = stockQuantity;
		this.usageInstruction = usageInstruction;
	}

	// 3. Getter và Setter
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public String getUsageInstruction() {
		return usageInstruction;
	}

	public void setUsageInstruction(String usageInstruction) {
		this.usageInstruction = usageInstruction;
	}
}