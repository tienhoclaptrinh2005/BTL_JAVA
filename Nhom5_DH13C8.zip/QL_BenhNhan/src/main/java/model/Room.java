package model;

import java.math.BigDecimal;

public class Room {
	private int id;
	private String roomNumber;
	private String type;
	private BigDecimal pricePerDay;

	// constructors
	public Room() {
	}

	public Room(int id, String roomNumber, String type, BigDecimal pricePerDay) {
		this.id = id;
		this.roomNumber = roomNumber;
		this.type = type;
		this.pricePerDay = pricePerDay;
	}

	// getters & setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public BigDecimal getPricePerDay() {
		return pricePerDay;
	}

	public void setPricePerDay(BigDecimal pricePerDay) {
		this.pricePerDay = pricePerDay;
	}
}