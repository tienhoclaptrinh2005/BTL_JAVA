package model;
import java.sql.Date;

public class Patient {
    private int id;
    private String fullName;
    private Date dob;
    private String gender;
    private String phone;
    private String address;
    private String insuranceCard;

    public Patient() {}

    public Patient(int id, String fullName, Date dob, String gender, String phone, String address, String insuranceCard) {
        this.id = id;
        this.fullName = fullName;
        this.dob = dob;
        this.gender = gender;
        this.phone = phone;
        this.address = address;
        this.insuranceCard = insuranceCard;
    }


    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public Date getDob() { return dob; }
    public void setDob(Date dob) { this.dob = dob; }
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getInsuranceCard() { return insuranceCard; }
    public void setInsuranceCard(String insuranceCard) { this.insuranceCard = insuranceCard; }
}