package model;

public class Doctor {

	private int id;
	private int userId;
	private int specialtyId;
	private String degree;
	private String bio;

	private String fullName;
	private String specialtyName;

	public Doctor() {
	}

	public Doctor(int id, int userId, int specialtyId, String degree, String bio, String fullName,
			String specialtyName) {
		this.id = id;
		this.userId = userId;
		this.specialtyId = specialtyId;
		this.degree = degree;
		this.bio = bio;
		this.fullName = fullName;
		this.specialtyName = specialtyName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getSpecialtyId() {
		return specialtyId;
	}

	public void setSpecialtyId(int specialtyId) {
		this.specialtyId = specialtyId;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	// Getter Setter cho các trường hiển thị
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getSpecialtyName() {
		return specialtyName;
	}

	public void setSpecialtyName(String specialtyName) {
		this.specialtyName = specialtyName;
	}
}