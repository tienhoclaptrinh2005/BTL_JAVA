package model;

import java.sql.Date;

public class Schedule {
	private int id;
	private int doctorId;
	private Date workDate;
	private int shift;
	private boolean isBooked;

	public Schedule() {
	}

	public Schedule(int id, int doctorId, Date workDate, int shift, boolean isBooked) {
		this.id = id;
		this.doctorId = doctorId;
		this.workDate = workDate;
		this.shift = shift;
		this.isBooked = isBooked;
	}

	// Getters và Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public Date getWorkDate() {
		return workDate;
	}

	public void setWorkDate(Date workDate) {
		this.workDate = workDate;
	}

	public int getShift() {
		return shift;
	}

	public void setShift(int shift) {
		this.shift = shift;
	}

	public boolean isBooked() {
		return isBooked;
	}

	public void setBooked(boolean isBooked) {
		this.isBooked = isBooked;
	}

	// Hàm phụ trợ giúp hiển thị trên JSP đẹp hơn
	public String getShiftName() {
		if (this.shift == 1)
			return "Sáng (7h - 11h)";
		if (this.shift == 2)
			return "Chiều (13h - 17h)";
		return "Khác";
	}

	// Hàm phụ trợ giúp hiển thị trạng thái
	public String getStatusName() {
		return this.isBooked ? "Đã đặt" : "Còn trống";
	}
}