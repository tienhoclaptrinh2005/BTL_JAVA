package model;

public class Bed {
	private int id;
	private int roomId;
	private String bedNumber;
	private String status; // Trong, Dang su dung, Bao tri

	// Thêm trường để hiển thị
	private String roomNumber;
	private String roomType;

	// constructors
	public Bed() {
	}

	public Bed(int id, int roomId, String bedNumber, String status) {
		this.id = id;
		this.roomId = roomId;
		this.bedNumber = bedNumber;
		this.status = status;
	}

	// getters & setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getBedNumber() {
		return bedNumber;
	}

	public void setBedNumber(String bedNumber) {
		this.bedNumber = bedNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
}