package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Doctor;
import model.Specialty;

public class DoctorDAO {

	public List<Specialty> getAllSpecialties() {
		List<Specialty> list = new ArrayList<>();
		String sql = "SELECT * FROM specialties";
		try (Connection conn = DBConfig.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				list.add(new Specialty(rs.getInt("id"), rs.getString("name")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<Doctor> getAllDoctors() {
		List<Doctor> list = new ArrayList<>();
		String sql = "SELECT d.id, d.user_id, d.degree, d.bio, u.full_name, s.name as spec_name " + "FROM doctors d "
				+ "JOIN users u ON d.user_id = u.id " + "LEFT JOIN specialties s ON d.specialty_id = s.id";

		try (Connection conn = DBConfig.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				Doctor d = new Doctor();
				d.setId(rs.getInt("id"));
				d.setUserId(rs.getInt("user_id"));
				d.setDegree(rs.getString("degree"));
				d.setBio(rs.getString("bio"));
				d.setFullName(rs.getString("full_name"));
				d.setSpecialtyName(rs.getString("spec_name"));
				list.add(d);
			}
		} catch (Exception e) {
			System.out.println("Lỗi getAllDoctors: " + e.getMessage());
			e.printStackTrace();
		}
		return list;
	}

	public boolean addDoctor(Doctor d) {
		String sql = "INSERT INTO doctors (user_id, specialty_id, degree, bio) VALUES (?, ?, ?, ?)";
		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, d.getUserId());
			ps.setInt(2, d.getSpecialtyId());
			ps.setString(3, d.getDegree());
			ps.setString(4, d.getBio());
			return ps.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public Doctor getDoctorById(int id) {
		String sql = "SELECT d.*, u.full_name, s.name as spec_name FROM doctors d "
				+ "JOIN users u ON d.user_id = u.id "
				+ "LEFT JOIN specialties s ON d.specialty_id = s.id WHERE d.id = ?";
		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				Doctor d = new Doctor();
				d.setId(rs.getInt("id"));
				d.setUserId(rs.getInt("user_id"));
				d.setSpecialtyId(rs.getInt("specialty_id"));
				d.setDegree(rs.getString("degree"));
				d.setBio(rs.getString("bio"));
				d.setFullName(rs.getString("full_name"));
				d.setSpecialtyName(rs.getString("spec_name"));
				return d;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean updateDoctor(Doctor d) {
		String sql = "UPDATE doctors SET specialty_id=?, degree=?, bio=? WHERE id=?";
		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, d.getSpecialtyId());
			ps.setString(2, d.getDegree());
			ps.setString(3, d.getBio());
			ps.setInt(4, d.getId());
			return ps.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean deleteDoctor(int id) {
		String sql = "DELETE FROM doctors WHERE id = ?";
		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, id);
			return ps.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public List<Doctor> searchDoctor(String keyword) {
		List<Doctor> list = new ArrayList<>();
		String sql = "SELECT d.id, d.user_id, d.degree, d.bio, u.full_name, s.name as spec_name " + "FROM doctors d "
				+ "JOIN users u ON d.user_id = u.id " + "LEFT JOIN specialties s ON d.specialty_id = s.id "
				+ "WHERE u.full_name LIKE ?";
		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, "%" + keyword + "%");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Doctor d = new Doctor();
				d.setId(rs.getInt("id"));
				d.setUserId(rs.getInt("user_id"));
				d.setDegree(rs.getString("degree"));
				d.setBio(rs.getString("bio"));
				d.setFullName(rs.getString("full_name"));
				d.setSpecialtyName(rs.getString("spec_name"));
				list.add(d);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<model.Schedule> getSchedulesByDoctor(int doctorId) {
		List<model.Schedule> list = new ArrayList<>();
		String sql = "SELECT * FROM doctor_schedules WHERE doctor_id = ? ORDER BY work_date ASC, shift ASC";

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setInt(1, doctorId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				model.Schedule s = new model.Schedule();
				s.setId(rs.getInt("id"));
				s.setDoctorId(rs.getInt("doctor_id"));
				s.setWorkDate(rs.getDate("work_date"));
				s.setShift(rs.getInt("shift"));
				s.setBooked(rs.getBoolean("is_booked"));
				list.add(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}