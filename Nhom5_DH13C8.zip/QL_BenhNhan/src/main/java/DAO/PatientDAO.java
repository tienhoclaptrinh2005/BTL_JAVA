package DAO;

import model.Patient;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<Patient> searchPatient(String keyword) {
        List<Patient> list = new ArrayList<>();
        String query = "SELECT * FROM patients WHERE full_name LIKE ? OR phone LIKE ?";
        try {
            new DBConfig();
			conn = DBConfig.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Patient(
                    rs.getInt("id"), rs.getString("full_name"), rs.getDate("dob"),
                    rs.getString("gender"), rs.getString("phone"),
                    rs.getString("address"), rs.getString("insurance_card")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

  
    public void addPatient(Patient p) {
        String query = "INSERT INTO patients (full_name, dob, gender, phone, address, insurance_card) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            new DBConfig();
			conn = DBConfig.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, p.getFullName());
            ps.setDate(2, p.getDob());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getPhone());
            ps.setString(5, p.getAddress());
            ps.setString(6, p.getInsuranceCard());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}