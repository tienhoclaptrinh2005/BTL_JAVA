package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.User;

public class UserDAO {
	public static Connection openConnection() {
		Connection conn = null;
		try {
			System.out.println("Hello from DBConfig.driver " + DBConfig.driver);
			Class.forName(DBConfig.driver);
			conn = DriverManager.getConnection(DBConfig.url, DBConfig.user, DBConfig.password);
			System.out.println("connected successfully");
		} catch (Exception ex) {
			// TODO: handle exception
			ex.printStackTrace();
		}
		return conn;
	}

	public User checkLogin(String username, String password) {
		User user = null;
		String sql = "SELECT * FROM users WHERE username = ? AND password = ? AND is_active = 1";

		try (Connection conn = DBConfig.getConnection()) {
			if (conn == null)
				return null;

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setFullName(rs.getString("full_name"));
				user.setRole(rs.getString("role"));

				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getString("phone"));
				user.setActive(rs.getBoolean("is_active"));
				user.setCreatedAt(rs.getTimestamp("created_at"));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	public List<User> getAllUsers() {
		List<User> listUsers = new ArrayList<>();
		String sql = "select * from users";
		try (Connection conn = DBConfig.getConnection()) {
			if (conn == null) {
				return listUsers;
			}
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setFullName(rs.getString("full_name"));
				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getString("phone"));
				user.setRole(rs.getString("role"));
				user.setActive(rs.getBoolean("is_active"));
				user.setCreatedAt(rs.getTimestamp("created_at"));
				listUsers.add(user);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return listUsers;
	}

	public boolean insertUser(User user) {
		String sql = "INSERT INTO users (username, password, full_name, email, phone, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		boolean rowInserted = false;

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getFullName());
			ps.setString(4, user.getEmail());
			ps.setString(5, user.getPhone());
			ps.setString(6, user.getRole());
			ps.setBoolean(7, user.isActive());
			ps.setTimestamp(8, user.getCreatedAt());

			rowInserted = ps.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowInserted;
	}

	public boolean deleteUser(int id) {
		String sql = "DELETE FROM users WHERE id = ?";
		boolean rowDeleted = false;

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setInt(1, id);
			rowDeleted = ps.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowDeleted;
	}

	public User getUserById(int id) {
		User user = null;
		String sql = "SELECT * FROM users WHERE id = ?";

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setFullName(rs.getString("full_name"));
				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getString("phone"));
				user.setRole(rs.getString("role"));
				user.setActive(rs.getBoolean("is_active"));
				user.setCreatedAt(rs.getTimestamp("created_at"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	public boolean updateUser(User user) {
		String sql = "UPDATE users SET password=?, full_name=?, email=?, phone=?, role=?, is_active=? WHERE id=?";
		boolean rowUpdated = false;

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, user.getPassword());
			ps.setString(2, user.getFullName());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getPhone());
			ps.setString(5, user.getRole());
			ps.setBoolean(6, user.isActive());
			ps.setInt(7, user.getId());

			rowUpdated = ps.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rowUpdated;
	}

	public List<User> searchUsers(String keyword) {
		List<User> listUsers = new ArrayList<>();
		// Tìm kiếm theo username HOẶC fullName
		String sql = "SELECT * FROM users WHERE username LIKE ? OR full_name LIKE ?";

		try (Connection conn = DBConfig.getConnection()) {
			if (conn == null)
				return listUsers;

			PreparedStatement ps = conn.prepareStatement(sql);
			String searchPattern = "%" + keyword + "%";
			ps.setString(1, searchPattern);
			ps.setString(2, searchPattern);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setFullName(rs.getString("full_name"));
				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getString("phone"));
				user.setRole(rs.getString("role"));
				user.setActive(rs.getBoolean("is_active"));
				user.setCreatedAt(rs.getTimestamp("created_at"));
				listUsers.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listUsers;
	}
}
