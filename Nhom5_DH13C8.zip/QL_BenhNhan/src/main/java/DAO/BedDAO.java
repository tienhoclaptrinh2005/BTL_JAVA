package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Bed;

public class BedDAO {
	private Connection connection;

	public BedDAO() {
		this.connection = DBConfig.getConnection();
	}

	// THÊM CODE THỰC THI CHO CÁC METHOD

	public boolean addBed(Bed bed) {
		String sql = "INSERT INTO beds (room_id, bed_number, status) VALUES (?, ?, ?)";
		try (PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.setInt(1, bed.getRoomId());
			stmt.setString(2, bed.getBedNumber());
			stmt.setString(3, "Trong"); // Mặc định trạng thái Trống
			return stmt.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public List<Bed> getAllBedsWithRoomInfo() {
		List<Bed> beds = new ArrayList<>();
		String sql = "SELECT b.*, r.room_number, r.type as room_type " + "FROM beds b "
				+ "JOIN rooms r ON b.room_id = r.id " + "ORDER BY r.room_number, b.bed_number";
		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				Bed bed = new Bed();
				bed.setId(rs.getInt("id"));
				bed.setRoomId(rs.getInt("room_id"));
				bed.setBedNumber(rs.getString("bed_number"));
				bed.setStatus(rs.getString("status"));
				bed.setRoomNumber(rs.getString("room_number"));
				bed.setRoomType(rs.getString("room_type"));
				beds.add(bed);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return beds;
	}

	public int getTotalBeds() {
		String sql = "SELECT COUNT(*) FROM beds";
		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int getAvailableBeds() {
		String sql = "SELECT COUNT(*) FROM beds WHERE status = 'Trong'";
		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	// THÊM METHOD UPDATE BED STATUS
	public boolean updateBedStatus(int bedId, String status) {
		String sql = "UPDATE beds SET status = ? WHERE id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.setString(1, status);
			stmt.setInt(2, bedId);
			return stmt.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}