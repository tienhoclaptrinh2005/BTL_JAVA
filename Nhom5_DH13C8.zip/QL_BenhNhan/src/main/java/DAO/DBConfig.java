package DAO;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConfig {
	public static String driver = "com.mysql.cj.jdbc.Driver";
	public static String url = "jdbc:mysql://localhost:3306/hospital?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
	public static String user = "root";
	public static String password = "123456";
	

	public static Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, password);

		} catch (Exception ex) {
			System.out.println("Lỗi kết nối Database!");
			ex.printStackTrace();
		}
		return conn;
	}
}
