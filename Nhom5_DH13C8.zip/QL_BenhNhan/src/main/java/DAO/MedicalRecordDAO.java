package DAO;
import model.MedicalRecord;
import java.sql.*;

public class MedicalRecordDAO {
    // Nhận Connection từ ngoài để chạy Transaction
    public void insertRecord(Connection conn, MedicalRecord r) throws SQLException {
        String query = "INSERT INTO medical_records "
                     + "(patient_id, doctor_id, bed_id, diagnosis, symptoms, admission_date, discharge_date, status, schedule_id) "
                     + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, r.getPatientId());
            ps.setInt(2, r.getDoctorId());
            if (r.getBedId() == null) ps.setNull(3, java.sql.Types.INTEGER);
            else ps.setInt(3, r.getBedId());
            ps.setString(4, r.getDiagnosis());
            ps.setString(5, r.getSymptoms());
            ps.setDate(6, r.getAdmissionDate());
            ps.setDate(7, r.getDischargeDate());
            ps.setString(8, r.getStatus());
            ps.setInt(9, r.getScheduleId());
            ps.executeUpdate();
        }
    }
}