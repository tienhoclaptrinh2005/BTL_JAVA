package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Room;

public class RoomDAO {
	private Connection connection;

	public RoomDAO() {
		this.connection = DBConfig.getConnection();
	}

	// THÊM CODE THỰC THI CHO CÁC METHOD

	public boolean addRoom(Room room) {
		String sql = "INSERT INTO rooms (room_number, type, price_per_day) VALUES (?, ?, ?)";
		try (PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.setString(1, room.getRoomNumber());
			stmt.setString(2, room.getType());
			stmt.setBigDecimal(3, room.getPricePerDay());
			return stmt.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public List<Room> getAllRooms() {
		List<Room> rooms = new ArrayList<>();
		String sql = "SELECT * FROM rooms ORDER BY room_number";
		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				Room room = new Room();
				room.setId(rs.getInt("id"));
				room.setRoomNumber(rs.getString("room_number"));
				room.setType(rs.getString("type"));
				room.setPricePerDay(rs.getBigDecimal("price_per_day"));
				rooms.add(room);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rooms;
	}

	public int getTotalRooms() {
		String sql = "SELECT COUNT(*) FROM rooms";
		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
}