package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Medicine;

public class MedicineDAO {

	// 1. Lấy danh sách thuốc (Cho Admin hiển thị bảng)
	public List<Medicine> getAllMedicines() {
		List<Medicine> list = new ArrayList<>();
		String query = "SELECT * FROM medicines";

		try (Connection conn = DBConfig.getConnection();
				PreparedStatement ps = conn.prepareStatement(query);
				ResultSet rs = ps.executeQuery()) {

			while (rs.next()) {
				list.add(new Medicine(rs.getInt("id"), rs.getString("name"), rs.getString("unit"),
						rs.getDouble("price"), rs.getInt("stock_quantity"), // Tên cột DB
						rs.getString("usage_instruction")) // Tên cột DB
				);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// 2. Nhập kho (Cộng thêm số lượng) - Dùng cho Admin
	public void importStock(int id, int amountToAdd) {
		String query = "UPDATE medicines SET stock_quantity = stock_quantity + ? WHERE id = ?";

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {

			ps.setInt(1, amountToAdd);
			ps.setInt(2, id);
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 3. Trừ kho (Trừ đi số lượng khi bán) - Dùng cho Nhân viên
	public void deductStock(int id, int amountToDeduct) {
		String query = "UPDATE medicines SET stock_quantity = stock_quantity - ? WHERE id = ?";

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {

			ps.setInt(1, amountToDeduct);
			ps.setInt(2, id);
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 4. Tìm kiếm thuốc theo tên - Dùng cho Nhân viên tìm thuốc
	public List<Medicine> searchMedicine(String keyword) {
		List<Medicine> list = new ArrayList<>();
		String query = "SELECT * FROM medicines WHERE name LIKE ?";

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {

			ps.setString(1, "%" + keyword + "%");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				list.add(new Medicine(rs.getInt("id"), rs.getString("name"), rs.getString("unit"),
						rs.getDouble("price"), rs.getInt("stock_quantity"), rs.getString("usage_instruction")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// 5. Cập nhật giá thuốc (Option thêm cho Admin)
	public void updatePrice(int id, double newPrice) {
		String query = "UPDATE medicines SET price = ? WHERE id = ?";

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {

			ps.setDouble(1, newPrice);
			ps.setInt(2, id);
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}