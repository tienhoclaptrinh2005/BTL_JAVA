package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Schedule;

public class ScheduleDAO {

	public void addSchedule(Schedule s) throws Exception {
		String sql = "INSERT INTO doctor_schedules (doctor_id, work_date, shift, is_booked) VALUES (?, ?, ?, 0)";
		Connection conn = DBConfig.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, s.getDoctorId());
		ps.setDate(2, s.getWorkDate());
		ps.setInt(3, s.getShift());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}

	public List<Schedule> getAvailableSchedules(int doctorId) {
		List<Schedule> list = new ArrayList<>();
		String sql = "SELECT * FROM doctor_schedules WHERE doctor_id = ? AND is_booked = 0 ORDER BY work_date ASC, shift ASC";

		try (Connection conn = DBConfig.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setInt(1, doctorId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Schedule s = new Schedule();
				s.setId(rs.getInt("id"));
				s.setDoctorId(rs.getInt("doctor_id"));
				s.setWorkDate(rs.getDate("work_date"));
				s.setShift(rs.getInt("shift"));
				s.setBooked(rs.getBoolean("is_booked"));
				list.add(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// Hàm này cập nhật số lượng đã đặt (+1)
    // QUAN TRỌNG: Phải nhận Connection từ ngoài vào để chạy Transaction
    public void updateBookedCount(Connection conn, int scheduleId) throws SQLException {
        String query = "UPDATE schedules SET current_patients = current_patients + 1 WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, scheduleId);
        ps.executeUpdate();
    }
    
    
	
	
	
}