package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import model.CartItem;

public class PrescriptionDAO {

	// Hàm quan trọng: Lưu đơn thuốc + Chi tiết + Trừ kho
	// Trả về true nếu thành công, false nếu thất bại
	public boolean savePrescription(String note, List<CartItem> cart) {
		Connection conn = null;
		PreparedStatement psPrescription = null;
		PreparedStatement psDetail = null;
		PreparedStatement psUpdateStock = null;

		try {
			conn = DBConfig.getConnection();

			// 1. Tắt chế độ tự động lưu (Transaction) để đảm bảo toàn vẹn dữ liệu
			// Nếu lỗi ở bước nào thì sẽ hủy bỏ (Rollback) toàn bộ
			conn.setAutoCommit(false);

			// --- BƯỚC A: LƯU BẢNG ĐƠN THUỐC TỔNG (prescriptions) ---
			// medical_record_id tạm để 1 (hoặc null tùy DB cho phép), note lưu tên bệnh
			// nhân
			String sqlPrescription = "INSERT INTO prescriptions (medical_record_id, created_at, note) VALUES (1, NOW(), ?)";

			// RETURN_GENERATED_KEYS để lấy ID vừa tạo
			psPrescription = conn.prepareStatement(sqlPrescription, Statement.RETURN_GENERATED_KEYS);
			psPrescription.setString(1, note);
			psPrescription.executeUpdate();

			// Lấy ID đơn thuốc vừa sinh ra
			ResultSet rs = psPrescription.getGeneratedKeys();
			int prescriptionId = 0;
			if (rs.next()) {
				prescriptionId = rs.getInt(1);
			}

			// --- BƯỚC B: LƯU CHI TIẾT & TRỪ KHO ---
			String sqlDetail = "INSERT INTO prescription_details (prescription_id, medicine_id, quantity, dosage) VALUES (?, ?, ?, ?)";
			String sqlStock = "UPDATE medicines SET stock_quantity = stock_quantity - ? WHERE id = ?";

			psDetail = conn.prepareStatement(sqlDetail);
			psUpdateStock = conn.prepareStatement(sqlStock);

			for (CartItem item : cart) {
				// 1. Lưu vào bảng chi tiết
				psDetail.setInt(1, prescriptionId);
				psDetail.setInt(2, item.getMedicineId());
				psDetail.setInt(3, item.getQuantity());
				psDetail.setString(4, "Uống theo chỉ dẫn"); // dosage mặc định
				psDetail.addBatch(); // Gom lệnh lại chạy 1 lần

				// 2. Trừ kho
				psUpdateStock.setInt(1, item.getQuantity());
				psUpdateStock.setInt(2, item.getMedicineId());
				psUpdateStock.addBatch(); // Gom lệnh lại
			}

			// Chạy tất cả các lệnh đã gom
			psDetail.executeBatch();
			psUpdateStock.executeBatch();

			// --- BƯỚC C: CHỐT ĐƠN (COMMIT) ---
			conn.commit();
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			try {
				if (conn != null)
					conn.rollback(); // Có lỗi thì hoàn tác lại hết
			} catch (Exception ex) {
			}
			return false;
		} finally {
			// Đóng kết nối
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
			}
		}
	}
}